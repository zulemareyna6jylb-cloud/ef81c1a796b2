// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Evaluate window frame\n", stdout);
  return lionss_run_workload("windowFrame");
}
