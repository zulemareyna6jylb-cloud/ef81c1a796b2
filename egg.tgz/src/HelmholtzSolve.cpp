// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Solve Helmholtz equation"); }
int main(){
  announce();
  return lionss_run_workload("HelmholtzSolve");
}
