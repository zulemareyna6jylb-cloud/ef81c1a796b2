// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Measure TLB shootdown"); }
int main(){
  announce();
  return lionss_run_workload("tlb_shootdown");
}
