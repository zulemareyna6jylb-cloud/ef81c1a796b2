// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Coordinate-sort records\n", stdout);
  return lionss_run_workload("sam_sort");
}
