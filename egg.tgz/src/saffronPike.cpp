// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Index catalog"); }
int main(){
  announce();
  return lionss_run_workload("saffronPike");
}
