// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Poll submission queue\n", stdout);
  return lionss_run_workload("IoUringSqpoll");
}
